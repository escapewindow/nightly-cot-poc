# Changes

## 1.0.1 / 2013-05-01

  - Update method library version.

## 1.0.0 / 2012-11-09

  - Test integration for browsers.
  - New method library.

## 0.0.1 / 2012-10-22

  - Initial release
