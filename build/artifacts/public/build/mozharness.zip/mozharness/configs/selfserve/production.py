config = {
    "selfserve_url": "https://secure.pub.build.mozilla.org/buildapi/self-serve",
}
