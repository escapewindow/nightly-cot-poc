config = {
    'base_name': 'Android armv7 API 11+ %(branch)s',
    'stage_platform': 'android-api-11',
    'build_type': 'api-11-opt',
    'src_mozconfig': 'mobile/android/config/mozconfigs/android-api-11/nightly',
    'tooltool_manifest_src': 'mobile/android/config/tooltool-manifests/android/releng.manifest',
    'multi_locale_config_platform': 'android',
}
