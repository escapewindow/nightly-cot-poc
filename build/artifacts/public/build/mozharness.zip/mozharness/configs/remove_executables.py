config = {
    # We bake this directly into the tester image now...
    "download_minidump_stackwalk": False,
    "minidump_stackwalk_path": "/usr/local/bin/linux64-minidump_stackwalk",
    "exes": {}
}
