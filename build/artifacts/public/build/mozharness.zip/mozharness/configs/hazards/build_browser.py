config = {
  'build_command': "build.browser",
  'expect_file': "expect.browser.json",
}
