#!/usr/bin/env python
config = {
    "override_string": "TODO",
    "override_list": ['to', 'do'],
    "override_dict": {'to': 'do'},
    "keep_string": "don't change me",
}
