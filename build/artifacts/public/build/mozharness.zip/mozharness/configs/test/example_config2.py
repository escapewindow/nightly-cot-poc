config = {
    "beverage": "cider",
    "long_sleep_time": 300,
    "random_config_key2": "wunderbar",
}
