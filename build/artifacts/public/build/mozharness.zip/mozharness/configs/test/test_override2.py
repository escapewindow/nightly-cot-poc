#!/usr/bin/env python
config = {
    "override_string": "yay",
    "override_list": ["yay", 'worked'],
    "override_dict": {"yay": 'worked'},
}
