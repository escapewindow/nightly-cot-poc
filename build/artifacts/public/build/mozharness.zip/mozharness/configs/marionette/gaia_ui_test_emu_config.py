# This is a config file for gaiatest on emulators; it's meant to be used
# with the primary gaia-ui-test config file.

config = {
    'update_files': False,
    'emulator': 'arm',
}
