# This is a template config file for b2g emulator unittest testing

config = {
    # mozharness script options
    "installer_url": "https://ftp-ssl.mozilla.org/pub/mozilla.org/b2g/tinderbox-builds/mozilla-central-linux64_gecko/1365627906/b2g-23.0a1.multi.linux-x86_64.tar.bz2",
    "xre_url": "https://ftp-ssl.mozilla.org/pub/mozilla.org/xulrunner/nightly/2012/09/2012-09-20-03-05-43-mozilla-central/xulrunner-18.0a1.en-US.linux-x86_64.tar.bz2"
}
