config = {
    "gaia_json_path": "{repo_path}/raw-file/{revision}/gaia.json",
    "bypass_download_cache": True,
}
