import os

config = {
    'stage_platform': 'linux32_gecko-debug',
    'debug_build': True,
    'src_mozconfig': 'b2g/config/mozconfigs/linux32_gecko/debug',
}
