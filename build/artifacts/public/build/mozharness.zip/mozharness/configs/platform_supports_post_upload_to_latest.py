config = {
    'platform_supports_post_upload_to_latest': False,
}
