b2g_desktop_multilocale module
==============================

.. automodule:: b2g_desktop_multilocale
    :members:
    :undoc-members:
    :show-inheritance:
