marionette module
=================

.. automodule:: marionette
    :members:
    :undoc-members:
    :show-inheritance:
