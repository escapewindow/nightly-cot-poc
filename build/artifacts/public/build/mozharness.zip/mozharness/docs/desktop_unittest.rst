desktop_unittest module
=======================

.. automodule:: desktop_unittest
    :members:
    :undoc-members:
    :show-inheritance:
