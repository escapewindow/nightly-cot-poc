The files in this directory were imported from https://github.com/vdjeric/Snappy-Symbolication-Server/ and https://github.com/mstange/analyze-tryserver-profiles/ with the permission of their respective authors. Some of the files were then cleaned up to remove code that we don't use.

The dump_syms_mac binary was copied from the objdir of a Firefox build on Mac. It's a byproduct of the regular Firefox build process and gets generated in objdir/dist/host/bin/.
